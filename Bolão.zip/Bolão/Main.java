package Bolão;

public class Main {

    public static void main(String[] args){
       Bolao bolao = new Bolao();
       Jogar.printarMenu(bolao);
       

    }
    
}
